<template>
    <div>
        <img src="src/assets/gom2.png" style="width: 100%; height: 100%; margin-top: 0px 
        ; margin-bottom: 0px;">
    </div>
</template>

<script setup>

</script>

<style  scoped>

</style>